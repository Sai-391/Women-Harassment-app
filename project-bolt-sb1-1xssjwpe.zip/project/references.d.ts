/// <reference path="./node_modules/@nativescript/types-minimal/index.d.ts" />
