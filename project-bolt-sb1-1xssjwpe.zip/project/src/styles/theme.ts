export const theme = {
    colors: {
        primary: '#7c3aed',
        secondary: '#4f46e5',
        danger: '#ef4444',
        success: '#22c55e',
        warning: '#f59e0b',
        background: '#f8fafc',
        text: {
            primary: '#1e293b',
            secondary: '#64748b',
            light: '#f8fafc'
        }
    },
    fonts: {
        main: 'Roboto',
        heading: 'Poppins'
    },
    spacing: {
        xs: 4,
        sm: 8,
        md: 16,
        lg: 24,
        xl: 32
    }
};