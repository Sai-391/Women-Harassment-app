import { BaseNavigationContainer } from '@react-navigation/core';
import * as React from "react";
import { stackNavigatorFactory } from "react-nativescript-navigation";

import { LoginScreen } from "./auth/LoginScreen";
import { HomeScreen } from "./screens/HomeScreen";
import { ReportScreen } from "./screens/ReportScreen";
import { ResourcesScreen } from "./screens/ResourcesScreen";
import { SafetyScreen } from "./screens/SafetyScreen";
import { ProfileScreen } from "./screens/ProfileScreen";
import { AuthorityDashboard } from "./screens/AuthorityDashboard";
import { AdminDashboard } from "./screens/AdminDashboard";
import { WomenEmpowerment } from "./screens/WomenEmpowerment";
import { BottomTabBar } from "./navigation/BottomTabBar";

const StackNavigator = stackNavigatorFactory();

export const MainStack = () => {
    const [isAuthenticated, setIsAuthenticated] = React.useState(false);
    const [userRole, setUserRole] = React.useState<'authority' | 'admin' | 'student' | null>(null);

    return (
        <BaseNavigationContainer>
            <StackNavigator.Navigator
                initialRouteName="Login"
                screenOptions={({ navigation, route }) => ({
                    headerStyle: {
                        backgroundColor: "#7c3aed",
                    },
                    headerTintColor: "white",
                    headerShown: true,
                    // Add bottom tab bar to authenticated screens
                    cardStyle: { paddingBottom: isAuthenticated ? 60 : 0 },
                })}
            >
                {!isAuthenticated ? (
                    <>
                        <StackNavigator.Screen
                            name="Login"
                            component={LoginScreen}
                            options={{ headerShown: false }}
                            initialParams={{ setIsAuthenticated, setUserRole }}
                        />
                    </>
                ) : (
                    <>
                        <StackNavigator.Screen
                            name="Home"
                            component={userRole === 'authority' ? AuthorityDashboard :
                                     userRole === 'admin' ? AdminDashboard :
                                     HomeScreen}
                            options={{ title: "Safe Campus" }}
                        />
                        <StackNavigator.Screen
                            name="Report"
                            component={ReportScreen}
                            options={{ title: "Report Incident" }}
                        />
                        <StackNavigator.Screen
                            name="Resources"
                            component={ResourcesScreen}
                            options={{ title: "Support Resources" }}
                        />
                        <StackNavigator.Screen
                            name="Safety"
                            component={SafetyScreen}
                            options={{ title: "Safety Features" }}
                        />
                        <StackNavigator.Screen
                            name="Profile"
                            component={ProfileScreen}
                            options={{ title: "My Profile" }}
                        />
                        <StackNavigator.Screen
                            name="WomenEmpowerment"
                            component={WomenEmpowerment}
                            options={{ title: "Women Empowerment" }}
                        />
                    </>
                )}
            </StackNavigator.Navigator>
            {isAuthenticated && <BottomTabBar />}
        </BaseNavigationContainer>
    );
};