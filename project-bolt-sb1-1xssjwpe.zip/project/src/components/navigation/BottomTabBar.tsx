import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { theme } from "../../styles/theme";

export function BottomTabBar({ navigation, currentRoute }) {
    const tabs = [
        { name: 'Home', icon: '🏠' },
        { name: 'Report', icon: '🚨' },
        { name: 'Resources', icon: '📚' },
        { name: 'Profile', icon: '👤' }
    ];

    return (
        <flexboxLayout style={styles.container}>
            {tabs.map((tab) => (
                <stackLayout
                    key={tab.name}
                    className={`p-2 rounded-lg ${currentRoute === tab.name ? 'bg-purple-100' : ''}`}
                    onTap={() => navigation.navigate(tab.name)}
                    style={styles.tab}
                >
                    <label className="text-2xl mb-1">{tab.icon}</label>
                    <label className="text-xs" style={{ color: theme.colors.text.secondary }}>
                        {tab.name}
                    </label>
                </stackLayout>
            ))}
        </flexboxLayout>
    );
}

const styles = StyleSheet.create({
    container: {
        height: 60,
        backgroundColor: 'white',
        borderTopWidth: 1,
        borderTopColor: '#e5e7eb',
        flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'center',
    },
    tab: {
        alignItems: 'center',
        flex: 1,
    },
});