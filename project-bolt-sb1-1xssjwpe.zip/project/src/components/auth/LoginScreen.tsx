import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { theme } from "../../styles/theme";

export function LoginScreen({ navigation, route }) {
    const [username, setUsername] = React.useState("");
    const [password, setPassword] = React.useState("");
    const [errorMessage, setErrorMessage] = React.useState("");

    // Safely extract parameters with default fallback
    const { setIsAuthenticated, setUserRole } = route.params || {};

    const handleLogin = () => {
        // Clear previous error messages
        setErrorMessage("");

        // Input validation
        if (!username || !password) {
            setErrorMessage("Please enter both username and password");
            return;
        }

        try {
            // Simulate authentication
            const role = username.includes('admin') ? 'admin' : 
                        username.includes('authority') ? 'authority' : 'student';
            
            // Ensure functions exist before calling
            if (setIsAuthenticated) setIsAuthenticated(true);
            if (setUserRole) setUserRole(role);

            // Navigate to Home screen with role
            navigation.navigate('Home', { role });
        } catch (error) {
            setErrorMessage("Login failed. Please try again.");
            console.error("Login error:", error);
        }
    };

    return (
        <flexboxLayout style={styles.container}>
            <image 
                src="~/assets/logo.png" 
                style={styles.logo} 
                onLoaded={(args) => {
                    // Optional: Handle image loading
                    console.log("Logo loaded");
                }}
            />
            
            <label 
                className="text-3xl mb-8 font-bold text-center" 
                style={{ color: theme.colors.primary }}
            >
                Safe Campus
            </label>

            <stackLayout className="w-full px-6">
                <textField
                    hint="Username"
                    value={username}
                    onTextChange={(e) => {
                        setUsername(e.value || "");
                        // Clear error when user starts typing
                        setErrorMessage("");
                    }}
                    className="mb-4 p-4 rounded-lg bg-gray-100"
                />
                <textField
                    hint="Password"
                    secure={true}
                    value={password}
                    onTextChange={(e) => {
                        setPassword(e.value || "");
                        // Clear error when user starts typing
                        setErrorMessage("");
                    }}
                    className="mb-6 p-4 rounded-lg bg-gray-100"
                />

                {/* Error Message Display */}
                {errorMessage ? (
                    <label 
                        className="text-red-600 text-center mb-4"
                        style={styles.errorText}
                    >
                        {errorMessage}
                    </label>
                ) : null}

                <button
                    className="bg-purple-600 text-white p-4 rounded-lg mb-4"
                    onTap={handleLogin}
                >
                    Login
                </button>
                
                <button
                    className="text-purple-600 p-2"
                    onTap={() => navigation.navigate('ForgotPassword')}
                >
                    Forgot Password?
                </button>
            </stackLayout>
        </flexboxLayout>
    );
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100%',
        backgroundColor: '#f5f5f5'
    },
    logo: {
        width: 150,
        height: 150,
        marginBottom: 20,
        alignSelf: 'center'
    },
    errorText: {
        color: 'red',
        textAlignment: 'center',
        marginBottom: 10
    }
});

export default LoginScreen;