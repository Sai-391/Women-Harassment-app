import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { RouteProp } from "@react-navigation/core";
import { FrameNavigationProp } from "react-nativescript-navigation";
import { MainStackParamList } from "../../NavigationParamList";

type ReportScreenProps = {
    route: RouteProp<MainStackParamList, "Report">,
    navigation: FrameNavigationProp<MainStackParamList, "Report">,
};

const incidentTypes = [
    "Verbal Abuse",
    "Sexual Harassment",
    "Bullying",
    "Stalking",
    "Cyber Harassment",
    "Discrimination",
    "Abuse of Authority"
];

export function ReportScreen({ navigation }: ReportScreenProps) {
    const [anonymous, setAnonymous] = React.useState(true);
    const [selectedType, setSelectedType] = React.useState("");

    return (
        <scrollView className="bg-white">
            <flexboxLayout style={styles.container}>
                <label className="text-2xl mb-6 font-bold text-center text-purple-700">
                    Report an Incident
                </label>

                <label className="text-sm mb-2 text-gray-600">
                    Your safety is our priority. All reports are confidential.
                </label>

                <switch
                    checked={anonymous}
                    onCheckedChange={(args) => setAnonymous(args.value)}
                    className="mb-4"
                />
                <label className="text-sm mb-6 text-gray-600">
                    {anonymous ? "Anonymous Report" : "Identified Report"}
                </label>

                <label className="text-lg mb-2 font-semibold">Incident Type:</label>
                <listView
                    items={incidentTypes}
                    itemTemplate={(item) => (
                        <stackLayout
                            className={`p-3 m-1 rounded-lg ${
                                selectedType === item ? 'bg-purple-100' : 'bg-gray-100'
                            }`}
                            onTap={() => setSelectedType(item)}
                        >
                            <label className="text-gray-800">{item}</label>
                        </stackLayout>
                    )}
                    className="mb-4"
                />

                <textView
                    hint="Describe what happened..."
                    className="bg-gray-100 p-4 rounded-lg mb-4 h-32"
                />

                <button
                    className="bg-purple-600 text-white p-4 rounded-lg mb-4 w-64 text-center"
                    onTap={() => {
                        // Handle report submission
                        navigation.navigate("Home");
                    }}
                >
                    Submit Report
                </button>
            </flexboxLayout>
        </scrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        padding: 20,
        flexDirection: "column",
    },
});