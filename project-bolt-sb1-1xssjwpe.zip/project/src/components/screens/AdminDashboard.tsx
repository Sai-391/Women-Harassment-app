import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { theme } from "../../styles/theme";
import type { Report } from "../../types/user";

export function AdminDashboard({ navigation }) {
    const [reports, setReports] = React.useState<Report[]>([]);

    return (
        <scrollView className="bg-white">
            <flexboxLayout style={styles.container}>
                <label className="text-2xl mb-6 font-bold text-center" style={{ color: theme.colors.primary }}>
                    Admin Dashboard
                </label>

                <label className="text-lg mb-4 font-semibold">Active Reports</label>
                
                {reports.map((report) => (
                    <stackLayout
                        key={report.id}
                        className="bg-gray-100 p-4 rounded-lg mb-4 w-full"
                    >
                        <label className="text-lg font-bold" style={{ color: theme.colors.primary }}>
                            {report.title}
                        </label>
                        <label className="text-gray-600">
                            {report.description}
                        </label>
                        <stackLayout className="mt-2 space-y-2">
                            <button
                                className="bg-green-500 text-white p-2 rounded-lg"
                                onTap={() => {/* Handle resolution */}}
                            >
                                Mark as Resolved
                            </button>
                            <button
                                className="bg-orange-500 text-white p-2 rounded-lg"
                                onTap={() => {/* Handle update */}}
                            >
                                Update Status
                            </button>
                        </stackLayout>
                    </stackLayout>
                ))}
            </flexboxLayout>
        </scrollView>
    );
}