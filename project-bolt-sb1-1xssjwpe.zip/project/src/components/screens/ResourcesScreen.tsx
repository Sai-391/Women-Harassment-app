import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { RouteProp } from "@react-navigation/core";
import { FrameNavigationProp } from "react-nativescript-navigation";
import { MainStackParamList } from "../../NavigationParamList";
import { openUrl } from "@nativescript/core/utils";

type ResourcesScreenProps = {
    route: RouteProp<MainStackParamList, "Resources">,
    navigation: FrameNavigationProp<MainStackParamList, "Resources">,
};

interface Resource {
    title: string;
    description: string;
    contact?: string;
    url?: string;
}

const resources: Resource[] = [
    {
        title: "24/7 Helpline",
        description: "Immediate support available",
        contact: "1-800-SAFE-CAMPUS"
    },
    {
        title: "Counseling Services",
        description: "Professional mental health support",
        contact: "counseling@university.edu"
    },
    {
        title: "Legal Aid",
        description: "Free legal consultation and support",
        contact: "1-888-LEGAL-AID"
    },
    {
        title: "Online Resources",
        description: "Self-help guides and information",
        url: "https://safecampus.org/resources"
    }
];

export function ResourcesScreen({ navigation }: ResourcesScreenProps) {
    const handleResourceTap = (resource: Resource) => {
        if (resource.contact) {
            // Handle contact information
            alert(`Contact: ${resource.contact}`);
        }
        if (resource.url) {
            openUrl(resource.url);
        }
    };

    return (
        <scrollView className="bg-white">
            <flexboxLayout style={styles.container}>
                <label className="text-2xl mb-6 font-bold text-center text-purple-700">
                    Support Resources
                </label>

                {resources.map((resource, index) => (
                    <stackLayout
                        key={index}
                        className="bg-gray-100 p-4 rounded-lg mb-4 w-full"
                        onTap={() => handleResourceTap(resource)}
                    >
                        <label className="text-lg font-bold text-purple-700">
                            {resource.title}
                        </label>
                        <label className="text-gray-600 mb-2">
                            {resource.description}
                        </label>
                        {resource.contact && (
                            <label className="text-blue-600">
                                {resource.contact}
                            </label>
                        )}
                        {resource.url && (
                            <label className="text-blue-600">
                                Click to visit website
                            </label>
                        )}
                    </stackLayout>
                ))}
            </flexboxLayout>
        </scrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        padding: 20,
        flexDirection: "column",
    },
});