import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { theme } from "../../styles/theme";

export function WomenEmpowerment({ navigation }) {
    const [currentQuizIndex, setCurrentQuizIndex] = React.useState(0);

    const quizzes = [
        {
            question: "What is the definition of consent?",
            options: [
                "Explicit permission given freely",
                "Implied agreement",
                "Forced acceptance",
                "Silent agreement"
            ],
            correctAnswer: 0
        },
        // Add more quiz questions
    ];

    return (
        <scrollView className="bg-white">
            <flexboxLayout style={styles.container}>
                <label className="text-2xl mb-6 font-bold text-center" style={{ color: theme.colors.primary }}>
                    Women Empowerment
                </label>

                <stackLayout className="mb-8">
                    <label className="text-xl font-bold mb-4">Daily Inspiration</label>
                    <label className="text-gray-600 italic">
                        "The question isn't who's going to let me; it's who is going to stop me."
                        - Ayn Rand
                    </label>
                </stackLayout>

                <stackLayout className="bg-purple-100 p-4 rounded-lg mb-6">
                    <label className="text-lg font-bold mb-2">Knowledge Check</label>
                    <label className="text-gray-700 mb-4">
                        {quizzes[currentQuizIndex].question}
                    </label>
                    {quizzes[currentQuizIndex].options.map((option, index) => (
                        <button
                            key={index}
                            className="bg-white text-purple-700 p-3 rounded-lg mb-2"
                            onTap={() => {/* Handle answer selection */}}
                        >
                            {option}
                        </button>
                    ))}
                </stackLayout>

                <button
                    className="bg-purple-600 text-white p-4 rounded-lg"
                    onTap={() => {/* Navigate to resources */}}
                >
                    Explore More Resources
                </button>
            </flexboxLayout>
        </scrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        padding: 20,
        flexDirection: "column",
    },
});