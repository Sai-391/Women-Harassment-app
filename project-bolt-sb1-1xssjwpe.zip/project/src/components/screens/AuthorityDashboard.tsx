import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { theme } from "../../styles/theme";
import type { Report } from "../../types/user";

export function AuthorityDashboard({ navigation }) {
    const [reports, setReports] = React.useState<Report[]>([]);

    // Simulated reports data
    React.useEffect(() => {
        setReports([
            {
                id: '1',
                title: 'Harassment Report',
                description: 'Student reported verbal harassment',
                type: 'Harassment',
                status: 'pending',
                createdAt: new Date(),
                deadline: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days
                assignedTo: 'admin1'
            }
        ]);
    }, []);

    return (
        <scrollView className="bg-white">
            <flexboxLayout style={styles.container}>
                <label className="text-2xl mb-6 font-bold text-center" style={{ color: theme.colors.primary }}>
                    Authority Dashboard
                </label>

                <label className="text-lg mb-4 font-semibold">Pending Reports</label>
                
                {reports.map((report) => (
                    <stackLayout
                        key={report.id}
                        className="bg-gray-100 p-4 rounded-lg mb-4 w-full"
                    >
                        <label className="text-lg font-bold" style={{ color: theme.colors.primary }}>
                            {report.title}
                        </label>
                        <label className="text-gray-600 mb-2">
                            Status: {report.status}
                        </label>
                        <label className="text-red-500">
                            Deadline: {report.deadline?.toLocaleDateString()}
                        </label>
                        <button
                            className="bg-purple-600 text-white p-2 rounded-lg mt-2"
                            onTap={() => {/* Handle intervention */}}
                        >
                            Intervene
                        </button>
                    </stackLayout>
                ))}
            </flexboxLayout>
        </scrollView>
    );
}