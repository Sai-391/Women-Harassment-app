import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { RouteProp } from "@react-navigation/core";
import { FrameNavigationProp } from "react-nativescript-navigation";
import { MainStackParamList } from "../../NavigationParamList";

type HomeScreenProps = {
    route: RouteProp<MainStackParamList, "Home">,
    navigation: FrameNavigationProp<MainStackParamList, "Home">,
};

export function HomeScreen({ navigation }: HomeScreenProps) {
    return (
        <scrollView className="bg-white">
            <flexboxLayout style={styles.container}>
                <stackLayout className="items-center mb-8">
                    <label className="text-3xl font-bold text-center text-purple-700">
                        Your Safety
                    </label>
                    <label className="text-xl font-bold text-center text-purple-600">
                        Our Priority
                    </label>
                </stackLayout>
                
                <button
                    className="bg-red-500 text-white p-4 rounded-full mb-4 w-64 text-center"
                    onTap={() => navigation.navigate("Report")}
                >
                    🚨 Emergency Report
                </button>

                <button
                    className="bg-purple-600 text-white p-4 rounded-lg mb-4 w-64 text-center"
                    onTap={() => navigation.navigate("Resources")}
                >
                    📚 Support Resources
                </button>

                <button
                    className="bg-blue-600 text-white p-4 rounded-lg mb-4 w-64 text-center"
                    onTap={() => navigation.navigate("Safety")}
                >
                    🛡️ Safety Features
                </button>

                <button
                    className="bg-green-600 text-white p-4 rounded-lg mb-4 w-64 text-center"
                    onTap={() => navigation.navigate("WomenEmpowerment")}
                >
                    👥 Women Empowerment
                </button>
            </flexboxLayout>
        </scrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        padding: 20,
        flexDirection: "column",
        alignItems: "center",
    },
});