import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { RouteProp } from "@react-navigation/core";
import { FrameNavigationProp } from "react-nativescript-navigation";
import { MainStackParamList } from "../../NavigationParamList";
import { Dialogs } from "@nativescript/core";

type SafetyScreenProps = {
    route: RouteProp<MainStackParamList, "Safety">,
    navigation: FrameNavigationProp<MainStackParamList, "Safety">,
};

interface SafetyFeature {
    title: string;
    description: string;
    action: () => void;
    buttonText: string;
    buttonClass: string;
}

export function SafetyScreen({ navigation }: SafetyScreenProps) {
    const [locationSharing, setLocationSharing] = React.useState(false);

    const safetyFeatures: SafetyFeature[] = [
        {
            title: "Emergency SOS",
            description: "Quickly alert emergency contacts with your location",
            buttonText: "Activate SOS",
            buttonClass: "bg-red-500",
            action: () => {
                Dialogs.confirm({
                    title: "Activate SOS",
                    message: "This will alert your emergency contacts. Continue?",
                    okButtonText: "Activate",
                    cancelButtonText: "Cancel"
                }).then(result => {
                    if (result) {
                        alert("SOS signal sent to emergency contacts");
                    }
                });
            }
        },
        {
            title: "Location Sharing",
            description: "Share your real-time location with trusted contacts",
            buttonText: locationSharing ? "Stop Sharing" : "Start Sharing",
            buttonClass: locationSharing ? "bg-orange-500" : "bg-green-500",
            action: () => {
                setLocationSharing(!locationSharing);
                alert(locationSharing ? 
                    "Location sharing stopped" : 
                    "Location sharing activated");
            }
        },
        {
            title: "Safe Walk",
            description: "Get virtual company while walking to your destination",
            buttonText: "Start Safe Walk",
            buttonClass: "bg-blue-500",
            action: () => {
                navigation.navigate("Report");
            }
        }
    ];

    return (
        <scrollView className="bg-white">
            <flexboxLayout style={styles.container}>
                <label className="text-2xl mb-6 font-bold text-center text-purple-700">
                    Safety Features
                </label>

                {safetyFeatures.map((feature, index) => (
                    <stackLayout
                        key={index}
                        className="bg-gray-100 p-4 rounded-lg mb-4 w-full"
                    >
                        <label className="text-lg font-bold text-purple-700">
                            {feature.title}
                        </label>
                        <label className="text-gray-600 mb-4">
                            {feature.description}
                        </label>
                        <button
                            className={`${feature.buttonClass} text-white p-3 rounded-lg text-center`}
                            onTap={feature.action}
                        >
                            {feature.buttonText}
                        </button>
                    </stackLayout>
                ))}
            </flexboxLayout>
        </scrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        padding: 20,
        flexDirection: "column",
    },
});