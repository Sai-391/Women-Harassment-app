import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { theme } from "../../styles/theme";
import type { User } from "../../types/user";

export function ProfileScreen({ navigation }) {
    const [user, setUser] = React.useState<User>({
        id: '1',
        username: 'user123',
        email: 'user@example.com',
        role: 'student',
        fullName: 'Jane Doe',
        department: 'Computer Science',
        contactNumber: '123-456-7890'
    });

    return (
        <scrollView className="bg-white">
            <flexboxLayout style={styles.container}>
                <stackLayout className="items-center mb-6">
                    <image
                        src={user.profileImage || "~/assets/default-avatar.png"}
                        className="rounded-full w-24 h-24 mb-4"
                    />
                    <label className="text-2xl font-bold" style={{ color: theme.colors.primary }}>
                        {user.fullName}
                    </label>
                    <label className="text-gray-600">
                        {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                    </label>
                </stackLayout>

                <stackLayout className="w-full space-y-4">
                    <stackLayout className="bg-gray-100 p-4 rounded-lg">
                        <label className="text-sm text-gray-600">Email</label>
                        <label className="text-lg">{user.email}</label>
                    </stackLayout>

                    <stackLayout className="bg-gray-100 p-4 rounded-lg">
                        <label className="text-sm text-gray-600">Department</label>
                        <label className="text-lg">{user.department}</label>
                    </stackLayout>

                    <stackLayout className="bg-gray-100 p-4 rounded-lg">
                        <label className="text-sm text-gray-600">Contact</label>
                        <label className="text-lg">{user.contactNumber}</label>
                    </stackLayout>

                    <button
                        className="bg-purple-600 text-white p-4 rounded-lg"
                        onTap={() => {/* Handle edit profile */}}
                    >
                        Edit Profile
                    </button>

                    <button
                        className="bg-red-500 text-white p-4 rounded-lg"
                        onTap={() => navigation.navigate('Login')}
                    >
                        Logout
                    </button>
                </stackLayout>
            </flexboxLayout>
        </scrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        padding: 20,
        flexDirection: "column",
    },
});