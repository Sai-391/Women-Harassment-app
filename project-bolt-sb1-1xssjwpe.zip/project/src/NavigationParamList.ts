export type MainStackParamList = {
    Login: undefined;
    Register: undefined;
    Home: { role?: 'authority' | 'admin' | 'student' };
    Report: undefined;
    Resources: undefined;
    Safety: undefined;
    Profile: undefined;
    AuthorityDashboard: undefined;
    AdminDashboard: undefined;
    WomenEmpowerment: undefined;
};