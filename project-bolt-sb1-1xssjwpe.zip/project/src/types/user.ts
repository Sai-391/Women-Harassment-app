export interface User {
    id: string;
    username: string;
    email: string;
    role: 'authority' | 'admin' | 'student';
    fullName: string;
    department?: string;
    contactNumber?: string;
    profileImage?: string;
}

export interface Report {
    id: string;
    title: string;
    description: string;
    type: string;
    status: 'pending' | 'in-progress' | 'resolved';
    createdAt: Date;
    images?: string[];
    location?: {
        latitude: number;
        longitude: number;
    };
    isAnonymous: boolean;
    reportedBy?: string;
    assignedTo?: string;
    deadline?: Date;
}